﻿using System.ComponentModel.DataAnnotations;

namespace WebsiteBanDienThoai23.AdminWeb.Models
{
    public class DangNhap
    {
        public string TenTaiKhoan { get; set; }
        public string MatKhau { get; set;}
    }
}
