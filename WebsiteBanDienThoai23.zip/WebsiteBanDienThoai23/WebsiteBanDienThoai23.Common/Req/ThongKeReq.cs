﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebsiteBanDienThoai23.Common.Req
{
	public class ThongKeReq
	{
		public string MaLoai { get; set; }
		public string TenLoai { get; set; }
		public int TonKho { get; set; }
	}
}