﻿using Microsoft.AspNetCore.Mvc;

namespace WebsiteBanDienThoai23.Web.Controllers
{
    public class PurchaseOrderController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
