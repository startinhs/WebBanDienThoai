﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebsiteBanDienThoai23.Common.Req
{
    public class LoaiSpReq
    {
        public string MaLoai { get; set; }
        public string TenLoai { get; set; }
        public string Hinh { get; set; }
    }
}
