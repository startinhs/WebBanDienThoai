$(document).ready(function(){
    $(".fa-bars").click(function(){
        $(".header-list--menu ul").slideToggle();
    });
});