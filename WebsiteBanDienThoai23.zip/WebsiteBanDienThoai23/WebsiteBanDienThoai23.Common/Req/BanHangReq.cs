﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebsiteBanDienThoai23.Common.Req
{
    public class BanHangReq
    {

    }
}
