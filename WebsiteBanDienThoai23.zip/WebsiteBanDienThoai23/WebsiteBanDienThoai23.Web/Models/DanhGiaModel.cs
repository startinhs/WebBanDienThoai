﻿namespace WebsiteBanDienThoai23.Web.Models
{
    public class DanhGiaModel
    {
        public string HoTen { get; set; }
        public int? SoSao { get; set; }
        public string BinhLuan { get; set; }
    }
}
